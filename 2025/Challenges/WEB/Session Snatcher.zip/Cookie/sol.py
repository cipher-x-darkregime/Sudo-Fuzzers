import requests

url = "http://localhost:5000/"  # Replace with the actual URL
cookies = {
    "admin": "True"
}

response = requests.get(url, cookies=cookies)
print(response.text)
