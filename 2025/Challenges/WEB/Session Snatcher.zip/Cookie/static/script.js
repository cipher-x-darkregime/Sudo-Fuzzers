function hint()
{
    var x="Morning milk with chocolaty snack is always incomplete"
    document.getElementById("hide").innerHTML = x;
    console.log("Heelo rushh")
}